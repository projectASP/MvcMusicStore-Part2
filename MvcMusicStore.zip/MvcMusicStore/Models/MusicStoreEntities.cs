﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity; 
//import System.Data.Entity;

    //step 28: Populate with sample data from previous content download: <link>
    //stopping here for tonight. Will resume later this weekend or on Monday if we meet up.

namespace MvcMusicStore.Models
{
    public class MusicStoreEntities : DbContext //MusicStoreEntities class "is a/inherits" DbContext class
    { 
        public DbSet<Album> Albums { get; set; }
        public DbSet<Genre> Genres { get; set; }

    }
}