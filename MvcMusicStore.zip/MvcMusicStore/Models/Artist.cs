﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


//~step 23: Create Artist Model &  Download entity framework in package manager 
    //Album will be associated with Album Model
namespace MvcMusicStore.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }
        public string Name { get; set; }
        
    }
}