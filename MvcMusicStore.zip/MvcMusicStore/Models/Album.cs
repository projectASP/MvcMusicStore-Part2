﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


// ~step 13: Create Album model class  (parent of Genre)

// ~step 24: update Album model
namespace MvcMusicStore.Models
{
    public class Album
    {
        public string Title { get; set; }
        public string Genre {get; set; }
        //Update with more fields on step 24

        public int AlbumId { get; set; }
        public int GenreId { get; set; }
        public int ArtistId { get; set; }

        public decimal Price { get; set; }
        public string AlbumArtUrl { get; set; }

        public Artist Artist { get; set; }
    }
}